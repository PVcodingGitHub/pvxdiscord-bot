const { Client, GatewayIntentBits } = require('discord.js');
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
});

const { ChatGPT } = require('openai');
const openai = new ChatGPT('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');

client.once('ready', () => {
  console.log('Bot is online!');
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand() || interaction.commandName !== 'ai') return;

  const prompt = interaction.options.getString('prompt');

  // Generate AI response
  const aiResponse = await openai.complete({
    prompt: prompt,
    maxTokens: 50,
    temperature: 0.7,
    n: 1,
    stop: '\n',
  });

  const aiMessage = aiResponse.choices[0].text.trim();

  // Reply to the interaction
  interaction.reply(aiMessage);
});

client.login('MTEyNTgzMTUwNTYxMzE2MDQ2OA.GKGV2e.4SYgl1t9lk4dxvdjzgpbve-tgTgHyi7-zrxEqE');
